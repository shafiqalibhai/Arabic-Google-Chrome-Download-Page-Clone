<div id="bottom"> </div>
<div id="footer">
&copy; <a href="#">2009</a>
</div>
</div>

</body>
</html>