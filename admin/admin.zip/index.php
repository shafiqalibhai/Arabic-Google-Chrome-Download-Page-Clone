<?php include"include/session.php" ?>
<?php include"header.php" ?>
<?php include "menu.php" ?>
<?php include "body.php" ?>
<?php include "footer.php" ?>